package Logic;

import java.util.Iterator;

public enum BookingState
{
		Available,
		Blocked,
		Booked

}