package Logic;

import java.sql.Time;
import java.util.Scanner;

public class Show {
    int showId;
	Time showStartTime;
	Time showEndTime;
	Seats[] seats;
	String showName;
	Movie movieName;
	int screenId;
	int theaterId;

	public boolean updateSeatsStatus(String[][] seats)
	{
		for (int i=0; i < seats.length; i++)
		{
			System.out.print((i+1)+" ");
			for (int j=0; j < seats[i].length; j++)
			System.out.print(seats[i][j] + " ");
			System.out.println();
			
		}
		return true;
		
	}
	
	public Seat[] chooseSeats(String[] seat)
	{
		//solution in notepad 
	}
	
	public boolean  intiateBooking(Seat[] Show)
	{
		//solution in notepad 	
     }
}


