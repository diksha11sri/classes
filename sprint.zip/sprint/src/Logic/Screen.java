package Logic;

import java.util.Date;
import java.util.Iterator;

public class Screen extends Show {
	
     int screenId;
	 int theatreId;
	 String screenName;
     Show[] showList;
	 int rows;
	 int columns;

	String mov_name[]= {"PK", "Baby"};
	String the_name[]= {"Royal Cinema", "Fun Cinema"};
	
	
	public Show searchShow(String b) {

		Iterator it=Screen.a.iterator();
		while(it.hasNext())
		{
			int flag=0;
			//bean class
		ScreenAttributes ob=(ScreenAttributes)it.next();
		for(int m=0;m<mov_name.length;m++)
		{
			
        if(mov_name[m].equals(b))
        {
        	for(int t=0;t<the_name.length;t++)
			{
				System.out.println("screen id:\n"+ob.getScreenId());
				System.out.println("theatre id:\n"+ob.getTheatreId());
				System.out.println("number of rows in theatre:\n"+ob.getRows());
				System.out.println("number of column in theatre:\n"+ob.getColumns());
            }
           flag=1;	
           break;
        }
		}
		if (flag==0)
		{
			
	        	System.out.println("*********************Invalid Show************");
	        
		}
		}
	}
	public Show[] showShows() {

		Iterator it=Screen.a.iterator();
		while(it.hasNext())
		{
			//bean class
			ScreenAttributes ob=(ScreenAttributes)it.next();
			for(int m=0;m<mov_name.length;m++)
			{
		    		for(int t=0;t<the_name.length;t++)
		    		{
		
			System.out.println("screen id:\n"+ob.getScreenId());
			System.out.println("theatre id:\n"+ob.getTheatreId());
			System.out.println("number of rows in theatre:\n"+ob.getRows());
			System.out.println("number of column in theatre:\n"+ob.getColumns());
		}
			}
		}
	}
}
